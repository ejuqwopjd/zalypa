
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="res-Pol10ap/js-Pol10ap/jqueryPol10ap.file.min.js"></script>


        <title>Контакт</title>
        <meta property="og:title" content="Контакт" />
        <meta property="og:image" content="logotip.svg"/>
        
        <meta property="og:description" content="Контакт">
        <meta name="description" content="Контакт">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/bootstrapPol10ap.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/bootstrapPol10ap.min.css.map">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/buttonPol10ap.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/jqueryPol10ap.fancybox.min.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/iconsPol10ap.css">

        <link rel="stylesheet" type="text/css" href="res-Pol10ap/css-Pol10ap/slickPol10ap.css"/>
        <link rel="stylesheet" type="text/css" href="res-Pol10ap/css-Pol10ap/slick-themePol10ap.css"/>

        <script src="res-Pol10ap/js-Pol10ap/jqueryPol10ap.cookie.file.js"></script>
        <script src="res-Pol10ap/js-Pol10ap/bootstrapPol10ap.min.js"></script>



        

        <link rel="shortcut icon" href="logotip.svg" type="image/x-icon">
        <link rel="stylesheet" href="index.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/media-queryPol10ap.css">



        

        <style>
            #cookie-RoVlzUV{
    display: none;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    bottom: 24px;
    left: 50%;
    width: 1126px;
    max-width: 90%;
    transform: translateX(-50%);
    padding: 24px;
    background-color:  #2A2438;
    border-radius: 15px;
    box-shadow: 2px 3px 10px rgba(0, 0, 0, 0.9);
    gap: 24px;
    z-index: 999999;
}
#cookie-RoVlzUV button{
    max-width: 200px;
    width: 100%;
}

#cookie-RoVlzUV p{
    margin: 0;
    font-size: 16px;
    color: #fff;
}


@media (min-width: 576px){
    #cookie-RoVlzUV.show{
        display: flex;
    }
    .cookie_accept{
        margin: 0 0 0 25px;
    }
}

@media (max-width: 575px){
    #cookie-RoVlzUV.show{
        display: flex;
        flex-direction: column;
    }
    .cookie_accept{
        margin: 10px 0 0 0;
    }
    button{
        width: 100%;
    }
}
#initco{margin-top:-10px!important;padding-left:0!important;padding-right:0!important}
.fa-copy:before{content:'0c5'}
.fa-chevron-down:before{content:'078'}
.logintableborder7 {
	border-top: 2px solid #C4D4DD;
	border-bottom: 2px solid #C4D4DD;
}
.fa-snapchat:before{content:'2ab'}
.ml h3 {
    font-size:14px;
    margin:7px 0 14px 0;
    padding-bottom:7px;
    font-weight: bold;
    color: #000000;
}
#output pre.xml {
	height: 100%;
	width: 100%;
}
.cm-s-default .cm-quote {
    color: #090
}
.ui-icon-closethick { background-position: -96px -128px; }
.sig-paren {
    font-size: larger;
}

        </style>
        </head>

        <body>

        <div id="cookie-RoVlzUV">
            <p>Мы используем файлы cookie для улучшения сайта и его взаимодействия с пользователями. Продолжая использовать сайт, вы соглашаетесь на использование файлов cookie. Вы всегда можете отключить файлы cookie в настройках вашего браузера.</p>
            <button class="button-2 cookie_accept" style="margin: 0;">Принимать</button>
        </div>

        <script type="text/javascript">

            function checkCookiesMss(){
                let cookieDate = localStorage.getItem('cookie-RoVlzUV--cookieDate');
                let cookieNotification = document.getElementById('cookie-RoVlzUV');
                let cookieBtn = cookieNotification.querySelector('.cookie_accept');

                if( !cookieDate || (+cookieDate + 31536000000) < Date.now() ){
                    cookieNotification.classList.add('show');
                }

                cookieBtn.addEventListener('click', function(){
                    localStorage.setItem( 'cookie-RoVlzUV--cookieDate', Date.now() );
                    cookieNotification.classList.remove('show');
                })
            }
            checkCookiesMss();
        </script>

            <header style="overflow: hidden;">
                <div class="hr">
                    <div class="hr-bg">
                        <div class="wave-color">
                            <div class="deco-wave"></div>
                            <div class="deco-line"></div>
                        </div>
                    </div>
                    <div class="container hr-site">
                        <a class="main-link" href="./">
                            <div class="site-logo">
                                <div class="logo-img">
                                    <img src="logotip.svg"  alt="">
                                </div>
                                <h2 class="logo-txt">Host Association</h2>
                            </div>
                        </a>
                        <nav class="nav-site">
                            <ul class="nav-list">
                                <li class="nav-item">
                                    <a href="./" class="nav-link"> Главная страница </a>
                                </li>
                                <li class="nav-item">
                                    <a href="./#faq" class="nav-link"> FAQ </a>
                                </li>
                                <li class="nav-item">
                                    <a href="contact.php" class="nav-link"> Контакт </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="container main-head">
                        <div class="main-txt">
                            <h1 class="main-title">
                                Приветствуем вас! Мы рады, что вы решили посетить нас сегодня и хотим поделится своими своими предложениями.
                            </h1>
                             
                        </div>
                        <div class="main-img">
                            <img src="bg/0_vectimg.svg" alt="">
                        </div>
                    </div>
                </div>
            </header>
        

<!-- тут верстаем -->

    <div class="container contact-page">
        <h2 class="contact-title"> Контакт</h2>
        <div class="container contact-block">
            <div class="card">
                <span class="form=title">Напишите нам</span>
                <form class="form" action="thanks_ru.html">
                  <div class="group">
                  <input placeholder="" type="text" required="required">
                  <label for="name">Введите Ваше имя</label>
                  </div>
                 <div class="group">
                  <input placeholder=""  id="phone" name="phone" required="required">
                  <label for="phone">Введите свой телефон</label>
                  </div>
                  <div class="group">
                    <input placeholder="" type="email" id="email" name="email" required="required">
                    <label for="email">Адрес электронной почты</label>
                    </div>
                    <button class="button-3">Отправить сообщение</button>
                </form>
            </div>
        <div class="contact-adress">
            <p class="adress-item"> </p>
            <p class="adress-item"> <i class="bi bi-shop"></i> ТРЦ «Экспобел», этаж 2 пересечение Логойского тракта и, МКАД, Минск 223053, Беларусь</p>
            <p class="adress-item">Почтовый адрес</p>
            <p class="adress-item"> <i class="bi bi-envelope-open"></i> royalcompany@mail.com</p>
            <p class="adress-item">Номер телефона</p>
            <p class="adress-item"> <i class="bi bi-telephone"></i> +375 1775 54-016</p>
        </div>
        
    </div>
   
    </div>

    <div class="map">
        <iframe src="https://maps.google.com/maps?hl=en&q=%D0%A2%D0%A0%D0%A6%20%C2%AB%D0%AD%D0%BA%D1%81%D0%BF%D0%BE%D0%B1%D0%B5%D0%BB%C2%BB%2C%20%D1%8D%D1%82%D0%B0%D0%B6%202%20%D0%BF%D0%B5%D1%80%D0%B5%D1%81%D0%B5%D1%87%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%9B%D0%BE%D0%B3%D0%BE%D0%B9%D1%81%D0%BA%D0%BE%D0%B3%D0%BE%20%D1%82%D1%80%D0%B0%D0%BA%D1%82%D0%B0%20%D0%B8%2C%20%D0%9C%D0%9A%D0%90%D0%94%2C%20%D0%9C%D0%B8%D0%BD%D1%81%D0%BA%20223053%2C%20%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%8C&ie=UTF8&t=&z=8&iwloc=B&output=embed" width="100%" height="283" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div> 

    <div class="spesial-link-bg">
        <div class="container spesial-link-block">
            <a class="spesial-link" href="privacy_read.html"> Политика конфиденциальности</a>
            <a class="spesial-link" href="term_read.html"> Сроки и условия </a>
            <a class="spesial-link" href="disclaimer_read.html">Отказ от ответственности</a>
        </div>
    </div>

    

</body>
</html>
