

<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="res-Pol10ap/js-Pol10ap/jqueryPol10ap.file.min.js"></script>


        <title>Психология инвестирования: эмоции и принятие финансовых решений</title>
        <meta property="og:title" content="Психология инвестирования: эмоции и принятие финансовых решений" />
        <meta property="og:image" content="1692233353.webp"/>
        
        <meta property="og:description" content="Психология инвестирования: эмоции и принятие финансовых решений">
        <meta name="description" content="Психология инвестирования: эмоции и принятие финансовых решений">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/bootstrapPol10ap.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/bootstrapPol10ap.min.css.map">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/buttonPol10ap.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/jqueryPol10ap.fancybox.min.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/iconsPol10ap.css">

        <link rel="stylesheet" type="text/css" href="res-Pol10ap/css-Pol10ap/slickPol10ap.css"/>
        <link rel="stylesheet" type="text/css" href="res-Pol10ap/css-Pol10ap/slick-themePol10ap.css"/>

        <script src="res-Pol10ap/js-Pol10ap/jqueryPol10ap.cookie.file.js"></script>
        <script src="res-Pol10ap/js-Pol10ap/bootstrapPol10ap.min.js"></script>



        
        
        <link rel="shortcut icon" href="logotip.svg" type="image/x-icon">
        <link rel="stylesheet" href="index.css">
        <link rel="stylesheet" href="res-Pol10ap/css-Pol10ap/media-queryPol10ap.css">



        

        <style>
            #cookie-RoVlzUV{
    display: none;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    bottom: 24px;
    left: 50%;
    width: 1126px;
    max-width: 90%;
    transform: translateX(-50%);
    padding: 24px;
    background-color:  #2A2438;
    border-radius: 15px;
    box-shadow: 2px 3px 10px rgba(0, 0, 0, 0.9);
    gap: 24px;
    z-index: 999999;
}
#cookie-RoVlzUV button{
    max-width: 200px;
    width: 100%;
}

#cookie-RoVlzUV p{
    margin: 0;
    font-size: 16px;
    color: #fff;
}


@media (min-width: 576px){
    #cookie-RoVlzUV.show{
        display: flex;
    }
    .cookie_accept{
        margin: 0 0 0 25px;
    }
}

@media (max-width: 575px){
    #cookie-RoVlzUV.show{
        display: flex;
        flex-direction: column;
    }
    .cookie_accept{
        margin: 10px 0 0 0;
    }
    button{
        width: 100%;
    }
}
#initco{margin-top:-10px!important;padding-left:0!important;padding-right:0!important}
.fa-copy:before{content:'0c5'}
.fa-chevron-down:before{content:'078'}
.logintableborder7 {
	border-top: 2px solid #C4D4DD;
	border-bottom: 2px solid #C4D4DD;
}
.fa-snapchat:before{content:'2ab'}
.ml h3 {
    font-size:14px;
    margin:7px 0 14px 0;
    padding-bottom:7px;
    font-weight: bold;
    color: #000000;
}
#output pre.xml {
	height: 100%;
	width: 100%;
}
.cm-s-default .cm-quote {
    color: #090
}
.ui-icon-closethick { background-position: -96px -128px; }
.sig-paren {
    font-size: larger;
}

        </style>
        </head>

        <body>

        <div id="cookie-RoVlzUV">
            <p>Мы используем файлы cookie для улучшения сайта и его взаимодействия с пользователями. Продолжая использовать сайт, вы соглашаетесь на использование файлов cookie. Вы всегда можете отключить файлы cookie в настройках вашего браузера.</p>
            <button class="button-2 cookie_accept" style="margin: 0;">Принимать</button>
        </div>

        <script type="text/javascript">

            function checkCookiesMss(){
                let cookieDate = localStorage.getItem('cookie-RoVlzUV--cookieDate');
                let cookieNotification = document.getElementById('cookie-RoVlzUV');
                let cookieBtn = cookieNotification.querySelector('.cookie_accept');

                if( !cookieDate || (+cookieDate + 31536000000) < Date.now() ){
                    cookieNotification.classList.add('show');
                }

                cookieBtn.addEventListener('click', function(){
                    localStorage.setItem( 'cookie-RoVlzUV--cookieDate', Date.now() );
                    cookieNotification.classList.remove('show');
                })
            }
            checkCookiesMss();
        </script>

            <header style="overflow: hidden;">
                <div class="hr">
                    <div class="hr-bg">
                        <div class="wave-color">
                            <div class="deco-wave"></div>
                            <div class="deco-line"></div>
                        </div>
                    </div>
                    <div class="container hr-site">
                        <a class="main-link" href="./">
                            <div class="site-logo">
                                <div class="logo-img">
                                    <img src="logotip.svg"  alt="">
                                </div>
                                <h2 class="logo-txt">Host Association</h2>
                            </div>
                        </a>
                        <nav class="nav-site">
                            <ul class="nav-list">
                                <li class="nav-item">
                                    <a href="./" class="nav-link"> Главная страница </a>
                                </li>
                                <li class="nav-item">
                                    <a href="./#faq" class="nav-link"> FAQ </a>
                                </li>
                                <li class="nav-item">
                                    <a href="contact.php" class="nav-link"> Контакт </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="container main-head">
                        <div class="main-txt">
                            <h1 class="main-title">
                                Приветствуем вас! Мы рады, что вы решили посетить нас сегодня и хотим поделится своими своими предложениями.
                            </h1>
                             
                        </div>
                        <div class="main-img">
                            <img src="bg/0_vectimg.svg" alt="">
                        </div>
                    </div>
                </div>
            </header>
        

            <section>
                <div id="stats" class="container 9KL8BP6 stat-block">
                    <div class="stat-item d-line">
                        <h3 class="stat-num"> 28402</h3>
                        <p class="stat-param"> <i class="bi bi-bar-chart"></i> Профессиональных агентов</p>
                    </div>
                    <div class="stat-item d-line">
                        <h3 class="stat-num"> 31276</h3>
                        <p class="stat-param"> <i class="bi bi-briefcase"></i> Принято заявок</p>
                    </div>
                    <div class="stat-item">
                        <h3 class="stat-num"> 7685</h3>
                        <p class="stat-param"> <i class="bi bi-calculator"></i> Телефонных звонков</p>
                    </div>
                </div>
            </section>

             

            <section>
                <div class="container main-content">
                    <h2 class="m-content-title"> Психология инвестирования: эмоции и принятие финансовых решений</h2>
                    <div class="m-content-block">
                        <div class="m-content-img">
                            <img class="m-c-img" src="1692233353.webp"  alt="">
                        </div>
                        <div class="m-content-text">
                            <p class="m-c-txt"> <p>Инвестиции в финансовые рынки &mdash; это не только игра с числами. Это сложное взаимодействие рационального анализа и запутанной паутины человеческих эмоций. Решения, которые мы принимаем как инвесторы, зависят не только от неопровержимых фактов, но и от нашего психологического склада. Понимание психологии инвестирования имеет решающее значение для принятия обоснованных финансовых решений и достижения долгосрочного успеха. В этой статье мы исследуем удивительную связь между эмоциями и принятием финансовых решений.</p>
<p><strong>Роль эмоций в инвестировании</strong></p>
<p>Эмоции играют значительную роль в инвестиционном процессе. Страх и жадность, в частности, являются сильными эмоциями, которые могут подтолкнуть инвесторов к принятию иррациональных решений. Когда рынки стремительно растут, жадность может привести к чрезмерному риску, подпитывая спекулятивное безумие. И наоборот, во время рыночных спадов страх может парализовать инвесторов, побуждая их продавать свои инвестиции в самый неподходящий момент. Взаимодействие между страхом и жадностью может создавать циклы рыночных подъемов и спадов, известные как рыночные настроения.</p>
<p><strong>Роль когнитивных искажений</strong></p>
<p>Когнитивные предубеждения &mdash; это неотъемлемые ярлыки человеческого мышления, которые могут влиять на принятие инвестиционных решений. Эти предубеждения могут искажать наше восприятие информации, приводя к иррациональным суждениям. Например, предвзятость подтверждения заставляет инвесторов искать информацию, которая поддерживает их существующие убеждения, игнорируя при этом противоположные доказательства. Предвзятость привязки возникает, когда инвесторы зацикливаются на определенной части информации, такой как цена покупки акции, и принимают последующие решения на основе этой привязки, а не объективно переоценивают ситуацию.</p>
<p><strong>Неприятие потерь и теория перспектив</strong></p>
<p>Неприятие потерь &mdash; это психологический феномен, при котором страдание от потерь ощущается сильнее, чем удовольствие от эквивалентной выгоды. Эта предвзятость может привести к тому, что инвесторы будут удерживать убыточные инвестиции дольше, чем должны, в надежде на возврат, вместо того, чтобы сокращать свои потери и перераспределять свои ресурсы. Теория перспектив, разработанная Даниэлем Канеманом и Амосом Тверски, утверждает,  что люди принимают решения, основываясь на предполагаемых прибылях и убытках по отношению к контрольной точке, а не сосредотачиваясь исключительно на конечном результате. Понимание этих предубеждений может помочь инвесторам лучше справляться со своими эмоциями и принимать более рациональные инвестиционные решения.</p>
<p><strong>Самоуверенность и стадный менталитет</strong></p>
<p>Излишняя самоуверенность является распространенным когнитивным искажением среди инвесторов. Это заставляет людей переоценивать свои способности и недооценивать риски, что приводит к чрезмерной торговле и неоптимальному управлению портфелем. Инвесторы, которые слишком самоуверенны, могут использовать стратегии выбора времени рынка или выбора акций, которые, скорее всего, будут хуже рынка в целом. Точно так же стадный менталитет может влиять на принятие решений,  поскольку инвесторы склонны следовать за действиями других, а не проводить независимый анализ. Это может привести к рыночным пузырям и неустойчивым тенденциям.</p>
<p><strong>Управление эмоциями для принятия лучших финансовых решений</strong></p>
<p>Признание влияния эмоций на инвестиционные решения &mdash; это первый шаг к тому, чтобы сделать правильный выбор. <em><strong>Вот несколько стратегий эффективного управления эмоциями:</strong></em></p>
<ol>
<li><strong>Образование и осведомленность.</strong> Понимание распространенных предубеждений и эмоциональных ловушек может помочь инвесторам понять, когда их суждения могут быть скомпрометированы.</li>
<li><strong>Долгосрочная перспектива.</strong> Долгосрочная перспектива помогает смягчить влияние краткосрочных рыночных колебаний, уменьшая тенденцию принимать импульсивные решения, основанные на эмоциях.</li>
<li><strong>Диверсификация.</strong> Распределение инвестиций по разным классам активов может уменьшить влияние отдельных результатов инвестиций, смягчая эмоциональные реакции.</li>
<li><strong>Установление реалистичных ожиданий</strong>. Установление реалистичных инвестиционных целей и понимание присущих им рисков может помочь справиться с эмоциями, связанными с чрезмерной жадностью или страхом.</li>
<li><strong>Поиск профессионального руководства.</strong> Работа с квалифицированным финансовым консультантом может обеспечить объективную перспективу и помочь инвесторам преодолеть эмоциональные ловушки.</li>
</ol>
<p><strong>Психология инвестирования &mdash; сложная область, в которой человеческие эмоции переплетаются с принятием финансовых решений.</strong> Эмоции могут как затуманивать суждения, так и стимулировать иррациональное поведение, что приводит к неоптимальным результатам инвестиций. Распознавание этих эмоций и управление ими необходимо инвесторам для принятия обоснованных финансовых решений. Понимая когнитивные предубеждения, установление реалистичных ожиданий и поддержание долгосрочной перспективы, инвесторы могут лучше ориентироваться в изменчивых водах финансовых рынков и достигать своих инвестиционных целей.</p></p>
                        </div>
                    </div>
                </div>
            </section>

            <section>
                <div class="comment-bg">
                    <div class="container comment">
                        <h2 class="contact-title">Отзывы клиентов</h2>
                        <div class="comment-block">
                            <div class="comm-slider">
                                <div class="comm-slider-item">
                                    <div class="comm-item-wrap">
                                        <div class="comm-text">
                                            <p class="comm-comment fst-normal">Работать с этой компанией всегда легко и приятно. </p>
                                            <p class="comm-person"> Александр Кириллов</p>
                                        </div>
                                        <div class="comm-avatar">
                                            <img class="avatar-img" src="avatar/m-0.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="comm-slider-item">
                                    <div class="comm-item-wrap">
                                        <div class="comm-text">
                                            <p class="comm-comment fst-normal">За прошедшие годы я пробовала много разных брендов, но продукты этой компании, безусловно, самые лучшие. Они эффективны и нежны для моей чувствительной кожи. </p>
                                            <p class="comm-person"> Владислав Сафонов</p>
                                        </div>
                                        <div class="comm-avatar">
                                            <img class="avatar-img" src="avatar/m-1.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="comm-slider-item">
                                    <div class="comm-item-wrap">
                                        <div class="comm-text">
                                            <p class="comm-comment fst-normal">Мне никогда не было так  приятно работать ни с одной с компанией как с этой. Их продукция качественная и доступная, а обслуживание клиентов не имеет себе равных. </p>
                                            <p class="comm-person"> Ева Воробьева </p>
                                        </div>
                                        <div class="comm-avatar">
                                            <img class="avatar-img" src="avatar/w-0.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="comm-slider-item">
                                    <div class="comm-item-wrap">
                                        <div class="comm-text">
                                            <p class="comm-comment fst-normal">Работать с этой компанией всегда легко, а их услуги всегда на высшем уровне. </p>
                                            <p class="comm-person"> Степан Никольский</p>
                                        </div>
                                        <div class="comm-avatar">
                                            <img class="avatar-img" src="avatar/m-1.jpg" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="comm-slider-item">
                                    <div class="comm-item-wrap">
                                        <div class="comm-text">
                                            <p class="comm-comment fst-normal">Очень рекомендую эту компанию за их профессиональных сотрудников, которые всегда стремятся удовлетворить потребности клиентов. </p>
                                            <p class="comm-person"> Анастасия Кузнецова </p>
                                        </div>
                                        <div class="comm-avatar">
                                            <img class="avatar-img" src="avatar/w-1.jpg" alt="">
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </section>

            <section>
                <div id="faq" class="container 4lbqVOftohz1 faq">
                    <h2 class="faq-title">
                        FAQ
                    </h2>
                    <div class="faq-block">
                        <div class="vector-img-form">
                            <div class="vector-img">
                                <img  src="bg/1_vectimg.svg" alt="">
                            </div>
                            <div class="card">
                                <span class="form=title">Напишите нам</span>
                                <form class="form" action="thanks_ru.html">
                                  <div class="group">
                                  <input placeholder="" type="text" required="required">
                                  <label for="name">Введите Ваше имя</label>
                                  </div>
                                 <div class="group">
                                  <input placeholder=""  id="phone" name="phone" required="required">
                                  <label for="phone">Введите свой телефон</label>
                                  </div>
                                  <div class="group">
                                    <input placeholder="" type="email" id="email" name="email" required="required">
                                    <label for="email">Адрес электронной почты</label>
                                    </div>
                                    <button class="button-2">Отправить сообщение</button>
                                </form>
                            </div>
                        </div>
                        <div class="faq-accordion">
                            <div class="accordion" id="accordionPanelsStayOpenExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="faq-question-one">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-answer-one" aria-expanded="true"
                                            aria-controls="faq-answer-one">
                                            Как компания поддерживает профессиональный рост своих сотрудников?
                                        </button>
                                    </h2>
                                    <div id="faq-answer-one" class="accordion-collapse collapse show"
                                        aria-labelledby="faq-question-one">
                                        <div class="accordion-body">
                                            Мы предоставляем возможности непрерывного обучения, программы развития навыков и наставничество, чтобы помочь нашим сотрудникам расти профессионально и вносить позитивный вклад в успех компании.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="faq-question-two">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-answer-two" aria-expanded="false"
                                            aria-controls="faq-answer-two">
                                            Какие стратегии использует компания для поддержания своей конкурентоспособности на рынке?
                                        </button>
                                    </h2>
                                    <div id="faq-answer-two" class="accordion-collapse collapse"
                                        aria-labelledby="faq-question-two">
                                        <div class="accordion-body">
                                            Мы остаемся конкурентоспособными, инвестируя в исследования и разработки, регулярно обновляя наши продукты и услуги и внимательно отслеживая тенденции рынка, чтобы адаптироваться к меняющимся потребностям наших клиентов.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item OpXdcXgD">
                                    <h2 class="accordion-header" id="faq-question-three">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-answer-three" aria-expanded="false"
                                            aria-controls="faq-answer-three">
                                            Какие виды услуг предоставляет компания?
                                        </button>
                                    </h2>
                                    <div id="faq-answer-three" class="accordion-collapse collapse"
                                        aria-labelledby="faq-question-three">
                                        <div class="accordion-body">
                                            Наша компания предоставляет широкий спектр услуг, в том числе [конкретные услуги], предназначенные для удовлетворения разнообразных потребностей наших клиентов в различных отраслях и секторах.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="faq-question-four">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                            data-bs-target="#faq-answer-four" aria-expanded="false"
                                            aria-controls="faq-answer-four">
                                            Как оставить отзыв о полученных услугах?
                                        </button>
                                    </h2>
                                    <div id="faq-answer-four" class="accordion-collapse collapse"
                                        aria-labelledby="faq-question-four">
                                        <div class="accordion-body">
                                            Мы ценим ваши отзывы. Вы можете оставить отзыв, заполнив опрос об удовлетворенности клиентов, который мы отправляем после завершения проекта, или связавшись с нашей службой поддержки клиентов.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>

            <section>
                <div class="container news-block">
                    <h2 class="news-title"> Последние новости</h2>
                    <div class="news">
                        <div class="left-side">
                            <div class="big-news-card">
                                <div class="big-news-img">
                                    <img src="1695100148.png" alt="">
                                </div>
                                <div class="news-text">
                                    <a href="indeksnie-fondi-sila-passivnogo-investirovaniya-diversifikatsii-riskov.php">
                                        <h4 class="n-title"> Индексные фонды: сила пассивного инвестирования и диверсификации рисков</h4>
                                    </a>
                                    <p class="news-txt"> Инвестиции в фондовый рынок традиционно ассоциируются с торговлей с высокими ставками и сложными стратегиями. Однако в последние годы все большее число...</p>
                                    <a class="news-link" href="indeksnie-fondi-sila-passivnogo-investirovaniya-diversifikatsii-riskov.php">Читать далее</a>
                                </div>
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="small-news-card">
                                <div class="small-news-img">
                                    <img src="1697671484.jpg " alt="">
                                </div>
                                <div class="small-news-text">
                                    <a href="investitsii-iskusstvo-strategii-perspektivi.php">
                                        <h4 class="s-n-title"> Инвестиции в искусство: стратегии и перспективы</h4>
                                    </a>
                                    <p class="s-news-txt"> Искусство издавна рассматривалось как источник эстетического удовольствия и культурного обогащения. Однако в последние годы он также стал жизнеспособным...</p>
                                    <a class="news-link" href="investitsii-iskusstvo-strategii-perspektivi.php">Читать далее</a>
                                </div>
                            </div>
                            <div class="small-news-card">
                                <div class="small-news-img">
                                    <img src="1696701655.png" alt="">
                                </div>
                                <div class="small-news-text">
                                    <a href="investitsii-vo-franshizi-otkritie-biznesa-vozmozhnosti-riski.php">
                                        <h4 class="s-n-title"> Инвестиции во франшизы и открытие бизнеса: возможности и риски</h4>
                                    </a>
                                    <p class="s-news-txt"> Инвестирование во франшизы и открытие бизнеса может быть заманчивой перспективой для людей, ищущих предпринимательские возможности. Оба варианта предлагают...</p>
                                    <a class="news-link" href="investitsii-vo-franshizi-otkritie-biznesa-vozmozhnosti-riski.php">Читать далее</a>
                                </div>
                            </div>
                            <div class="small-news-card">
                                <div class="small-news-img">
                                    <img src="1695530197.jpg" alt="">
                                </div>
                                <div class="small-news-text">
                                    <a href="investitsii-obligatsii-drugie-finansovie-instrumenti-vibor-optimalnogo-portfelya-dlya-sohraneniya-priumnozheniya-kapitala.php">
                                        <h4 class="s-n-title"> Инвестиции в облигации и другие финансовые инструменты: выбор оптимального портфеля для сохранения и приумножения капитала</h4>
                                    </a>
                                    <p class="s-news-txt"> В обширном ландшафте инвестиционных возможностей облигации и другие финансовые инструменты уже давно признаны важными инструментами для людей, стремящихся...</p>
                                    <a class="news-link" href="investitsii-obligatsii-drugie-finansovie-instrumenti-vibor-optimalnogo-portfelya-dlya-sohraneniya-priumnozheniya-kapitala.php">Читать далее</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>






        

            <footer>
                <div class="footer-color">
                    <div class="container">
                        <a class="footer-main-link" href="./">
                            <div class="footer-site-logo">
                                <div class="f-logo-img">
                                    <img src="logotip.svg"  alt="">
                                </div>
                                <h2 class="f-logo-txt">Host Association</h2>
                            </div>
                        </a>
                    </div>
                    <div class="container footer-block">
                            <nav class="footer-nav-site ">
                                <ul class="f-nav-list footer-wrap">
                                    <li class="f-nav-item">
                                        <a href="./" class="f-nav-link"> Главная страница</a>
                                    </li>
                                    <li class="f-nav-item">
                                        <a href="./#faq" class="f-nav-link"> FAQ </a>
                                    </li>
                                    <li class="f-nav-item">
                                        <a href="contact.php" class="f-nav-link"> Контакт </a>
                                    </li>
                                </ul>
                            </nav>
                        <div class="footer-wrap">
                            <p class="ogrn"> </p>
                            <p class="adress"> <i class="bi bi-shop"></i> ТРЦ «Экспобел», этаж 2 пересечение Логойского тракта и, МКАД, Минск 223053, Беларусь</p>
                            <p class="mail"> <i class="bi bi-envelope-open"></i> royalcompany@mail.com</p>
                            <p class="num"> <i class="bi bi-telephone"></i> +375 1775 54-016</p>
                        </div>
                        <div class="footer-wrap">
                            <a class="spesial-link" href="privacy_read.html"> Политика конфиденциальности</a>
                            <a class="spesial-link" href="term_read.html"> Сроки и условия </a>
                            <a class="spesial-link" href="disclaimer_read.html">Отказ от ответственности</a>
                        </div>
                    </div>
                </div>

                <div class="map">
                    <iframe src="https://maps.google.com/maps?hl=en&q=%D0%A2%D0%A0%D0%A6%20%C2%AB%D0%AD%D0%BA%D1%81%D0%BF%D0%BE%D0%B1%D0%B5%D0%BB%C2%BB%2C%20%D1%8D%D1%82%D0%B0%D0%B6%202%20%D0%BF%D0%B5%D1%80%D0%B5%D1%81%D0%B5%D1%87%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%9B%D0%BE%D0%B3%D0%BE%D0%B9%D1%81%D0%BA%D0%BE%D0%B3%D0%BE%20%D1%82%D1%80%D0%B0%D0%BA%D1%82%D0%B0%20%D0%B8%2C%20%D0%9C%D0%9A%D0%90%D0%94%2C%20%D0%9C%D0%B8%D0%BD%D1%81%D0%BA%20223053%2C%20%D0%91%D0%B5%D0%BB%D0%B0%D1%80%D1%83%D1%81%D1%8C&ie=UTF8&t=&z=8&iwloc=B&output=embed" width="100%" height="282" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </footer>


        


        <script type="text/javascript" src="res-Pol10ap/js-Pol10ap/jqueryPol10ap.fancybox.min.js"></script>
        <script type="text/javascript" src="res-Pol10ap/js-Pol10ap/tinycolor-minPol10ap.js"></script>

        <script type="text/javascript" src="res-Pol10ap/js-Pol10ap/slickPol10ap.file.min.js"></script>


        <script>
              if($('.m-content-block').css('flex-direction') == 'column') {
                $('.m-c-img img').css({'max-width': '800px'});
                $('.m-c-img').css({'overflow': 'visible'});
                $('.m-content-text').css({'width': '100%'});
            }
        </script>

        <script>
            let pictures = $('.m-c-img');

            function optomizImages(pictures){
                let iGloHeight = pictures.prop('naturalHeight');
                let GloWidth = pictures.prop('naturalWidth');

                if(iGloHeight > GloWidth){
                    if(iGloHeight > 800){
                        pictures.css('width','30%');
                    }
                }
            }
            optomizImages(pictures);
        </script>

<script>

    let color = $('.comment-bg').css('background-color');

    function convertHex(hex, opacity) {
        hex = hex.replace('#', '');
        r = parseInt(hex.substring(0, 2), 16);
        g = parseInt(hex.substring(2, 4), 16);
        b = parseInt(hex.substring(4, 6), 16);

        result = 'rgba(' + r + ',' + g + ',' + b + ',' + opacity / 100 + ')';
        return result;
    }

    $('.comment-bg').css('background-color', convertHex('#2A2438', 15));

</script>

<script>
    $(document).ready(function(){
$('.comm-slider').slick({
dots: true,
        slidesToShow: 1,
        arrows: false,
        responsive: [
            {
            breakpoint: 1024,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                dots: true,
                arrows: false
            }
            },
            {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                arrows: false
            }
            },
            {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: true,
                arrows: false
            }
            }
        ]
        });
});
</script>

<script>
    if ($('.card').length < 1) {
            $('.vector-img').css('display', 'block');
        }
</script>


        
    </body>
</html>

